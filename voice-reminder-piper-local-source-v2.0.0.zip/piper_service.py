#!/usr/bin/env python3
"""Local-only Piper HTTP bridge for Super Productivity.

This process deliberately listens only on 127.0.0.1.  It neither downloads
models nor reads task data from disk: text is received per request, rendered
with Piper, returned as a WAV response, and the temporary WAV is deleted.
"""

from __future__ import annotations

import argparse
import json
import subprocess
import tempfile
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Any

MAX_TEXT_LENGTH = 4_000


class PiperService:
    def __init__(self, piper_exe: Path, voices_dir: Path) -> None:
        self.piper_exe = piper_exe
        self.voices_dir = voices_dir

    def voices(self) -> list[dict[str, str]]:
        return [
            {"id": model.stem, "name": model.stem.replace("-", " ")}
            for model in sorted(self.voices_dir.glob("*.onnx"))
            if model.with_suffix(model.suffix + ".json").is_file()
        ]

    def model_path(self, model_id: str) -> Path:
        # Model ids are names discovered above, never client-supplied paths.
        candidate = self.voices_dir / f"{model_id}.onnx"
        if candidate.parent != self.voices_dir or not candidate.is_file():
            raise ValueError("Unknown Piper voice")
        if not candidate.with_suffix(candidate.suffix + ".json").is_file():
            raise ValueError("The selected voice has no matching .onnx.json file")
        return candidate

    def synthesize(self, text: str, model_id: str) -> bytes:
        if not isinstance(text, str) or not text.strip():
            raise ValueError("text must be a non-empty string")
        if len(text) > MAX_TEXT_LENGTH:
            raise ValueError(f"text must be at most {MAX_TEXT_LENGTH} characters")
        model = self.model_path(model_id)
        if not self.piper_exe.is_file():
            raise RuntimeError(f"Piper executable not found: {self.piper_exe}")

        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as wav_file:
            wav_path = Path(wav_file.name)
        try:
            result = subprocess.run(
                [
                    str(self.piper_exe),
                    "--model",
                    str(model),
                    "--config",
                    str(model.with_suffix(model.suffix + ".json")),
                    "--output_file",
                    str(wav_path),
                ],
                input=text,
                text=True,
                encoding="utf-8",
                capture_output=True,
                timeout=60,
                check=False,
            )
            if result.returncode != 0 or not wav_path.is_file():
                detail = result.stderr.strip() or "Piper did not create audio"
                raise RuntimeError(detail)
            return wav_path.read_bytes()
        except subprocess.TimeoutExpired as exc:
            raise RuntimeError("Piper timed out after 60 seconds") from exc
        finally:
            wav_path.unlink(missing_ok=True)


def json_response(handler: BaseHTTPRequestHandler, status: HTTPStatus, payload: Any) -> None:
    body = json.dumps(payload).encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Content-Length", str(len(body)))
    handler.send_header("Access-Control-Allow-Origin", "null")
    handler.end_headers()
    handler.wfile.write(body)


def make_handler(service: PiperService) -> type[BaseHTTPRequestHandler]:
    class Handler(BaseHTTPRequestHandler):
        server_version = "SuperProductivityPiper/1.0"

        def log_message(self, _format: str, *_args: object) -> None:
            # Never log reminder text or task titles.
            return

        def do_OPTIONS(self) -> None:  # noqa: N802
            self.send_response(HTTPStatus.NO_CONTENT)
            self.send_header("Access-Control-Allow-Origin", "null")
            self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "Content-Type")
            self.end_headers()

        def do_GET(self) -> None:  # noqa: N802
            if self.path == "/health":
                json_response(self, HTTPStatus.OK, {"ok": True})
            elif self.path == "/v1/voices":
                json_response(self, HTTPStatus.OK, {"voices": service.voices()})
            else:
                json_response(self, HTTPStatus.NOT_FOUND, {"error": "Not found"})

        def do_POST(self) -> None:  # noqa: N802
            if self.path != "/v1/synthesize":
                json_response(self, HTTPStatus.NOT_FOUND, {"error": "Not found"})
                return
            try:
                length = int(self.headers.get("Content-Length", "0"))
                if length <= 0 or length > MAX_TEXT_LENGTH + 2_000:
                    raise ValueError("Invalid request size")
                payload = json.loads(self.rfile.read(length).decode("utf-8"))
                if not isinstance(payload, dict):
                    raise ValueError("JSON object expected")
                audio = service.synthesize(payload.get("text"), payload.get("voice"))
            except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as exc:
                json_response(self, HTTPStatus.BAD_REQUEST, {"error": str(exc)})
                return
            except RuntimeError as exc:
                json_response(self, HTTPStatus.SERVICE_UNAVAILABLE, {"error": str(exc)})
                return

            self.send_response(HTTPStatus.OK)
            self.send_header("Content-Type", "audio/wav")
            self.send_header("Content-Length", str(len(audio)))
            self.send_header("Access-Control-Allow-Origin", "null")
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(audio)

    return Handler


def main() -> None:
    parser = argparse.ArgumentParser(description="Local Piper bridge for Super Productivity")
    parser.add_argument("--piper", type=Path, required=True, help="Path to piper.exe")
    parser.add_argument("--voices", type=Path, required=True, help="Folder containing Piper .onnx files")
    parser.add_argument("--port", type=int, default=8712)
    args = parser.parse_args()
    service = PiperService(args.piper.resolve(), args.voices.resolve())
    # One synthesis at a time keeps CPU and peak RAM bounded. The plugin sends
    # reminders serially, so concurrent request handling adds no user benefit.
    server = HTTPServer(("127.0.0.1", args.port), make_handler(service))
    print(f"Piper bridge listening at http://127.0.0.1:{args.port} (Ctrl+C to stop)")
    server.serve_forever()


if __name__ == "__main__":
    main()
