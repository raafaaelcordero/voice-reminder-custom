$ErrorActionPreference = 'Stop'
$listeners = Get-NetTCPConnection -LocalAddress '127.0.0.1' -LocalPort 8712 -State Listen -ErrorAction SilentlyContinue
if ($listeners) {
  $listeners | Select-Object -ExpandProperty OwningProcess -Unique | ForEach-Object { Stop-Process -Id $_ -Force }
  Write-Host 'Piper bridge stopped.'
} else {
  Write-Host 'No Piper bridge is listening on port 8712.'
}
