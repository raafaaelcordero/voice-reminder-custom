$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSCommandPath
$configPath = Join-Path $root 'bridge-config.json'

if (-not (Test-Path -LiteralPath $configPath)) {
  throw "Bridge configuration not found. Copy bridge-config.example.json to bridge-config.json and set your paths."
}

try {
  $config = Get-Content -LiteralPath $configPath -Raw | ConvertFrom-Json
} catch {
  throw "Bridge configuration is not valid JSON: $($_.Exception.Message)"
}

$python = [string]$config.python
$piper = [string]$config.piper
$voices = [string]$config.voices
$port = [int]$config.port

if (-not (Test-Path -LiteralPath $python)) { throw "Python not found: $python" }
if (-not (Test-Path -LiteralPath $piper)) { throw "Piper not found: $piper" }
if (-not (Test-Path -LiteralPath $voices)) { throw "Voice folder not found: $voices" }
if ($port -lt 1 -or $port -gt 65535) { throw "Port must be between 1 and 65535." }

& $python "$root\piper_service.py" --piper $piper --voices $voices --port $port
