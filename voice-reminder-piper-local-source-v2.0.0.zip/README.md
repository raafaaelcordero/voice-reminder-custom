# Recordatorios de voz con Piper local

Este complemento hace que Super Productivity te recuerde en voz alta la tarea en la que estás trabajando. Todo funciona en tu ordenador: no envía nada a Internet.

## Antes de empezar

Necesitas tres cosas:

1. Super Productivity para Windows.
2. Piper instalado en tu ordenador.
3. Una voz de Piper. Cada voz necesita dos archivos: uno termina en `.onnx` y otro en `.onnx.json`.

## Instalación fácil

### 1. Guarda esta carpeta

Guarda la carpeta del proyecto en un lugar fijo, por ejemplo dentro de `Documentos`. No la muevas después.

### 2. Indica dónde está Piper

1. Busca el archivo `bridge-config.example.json`.
2. Haz una copia y llámala `bridge-config.json`.
3. Ábrelo con el Bloc de notas.
4. Cambia las tres rutas por las de tu ordenador:

```json
{
  "python": "C:\\ruta\\a\\python.exe",
  "piper": "C:\\ruta\\a\\piper.exe",
  "voices": "C:\\ruta\\a\\la-carpeta-de-voces",
  "port": 8712
}
```

Solo tienes que hacerlo una vez. Este archivo es personal y no se comparte.

### 3. Enciende la voz local

Haz doble clic en `Start-Piper-Bridge.ps1`.

Debería aparecer un mensaje que dice que Piper está listo en el puerto `8712`. Deja esa ventana abierta mientras uses los recordatorios. Si prefieres que se inicie oculto al encender Windows, crea un acceso directo en `shell:startup` con este destino:

```text
powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "C:\ruta\a\la\carpeta\Start-Piper-Bridge.ps1"
```

Sustituye `C:\ruta\a\la\carpeta` por la ubicación real de esta carpeta.

### 4. Instala el complemento

1. Abre Super Productivity.
2. Ve a **Ajustes → Plugins**.
3. Pulsa **Choose Plugin File**.
4. Elige `voice-reminder-piper-local.zip` de la carpeta `dist`.
5. Acepta el aviso de seguridad: es un complemento local que has descargado de esta carpeta.

### 5. Configúralo

1. En la tarjeta **Voice Reminder — Piper Local**, pulsa **Configurar**.
2. Elige **Piper local**.
3. Elige una voz, por ejemplo Davefx.
4. Pulsa **Probar voz**.
5. Activa el recordatorio y pulsa **Guardar**.

## Frases y títulos de tareas

El texto por defecto usa `${currentTaskTitle}`. Eso significa: “di el título de la tarea que está activa”.

Puedes usar frases personalizadas, una por línea:

```text
Vamos con ${currentTaskTitle}.
Sigue con ${currentTaskTitle}.
Un momento para concentrarte.
```

Activa **Alternar frases motivadoras** para que no repita siempre la misma.

## Si algo no funciona

- Si Piper no habla, pulsa **Probar voz** y comprueba las tres rutas de `bridge-config.json`.
- Si sigue sin responder, el complemento usará la voz de Windows como alternativa.
- Para detener Piper, ejecuta `Stop-Piper-Bridge.ps1`.

## Privacidad

El título de la tarea se envía únicamente a Piper en tu propio ordenador (`127.0.0.1`). No hay cuentas, anuncios, telemetría ni servicios en la nube. Lee [PRIVACY.md](PRIVACY.md) para el detalle.

## Para publicar una versión nueva

Ejecuta `Pack-Release.ps1`. Creará el ZIP del plugin y su código SHA-256 en la carpeta `dist`.
