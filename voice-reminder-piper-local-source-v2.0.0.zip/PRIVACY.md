# Privacy policy

Voice Reminder — Piper Local runs on the user's computer.

- The plugin sends the active task title and the configured reminder text only to the configured local bridge at `127.0.0.1`.
- The bridge listens only on the local computer, returns synthesized WAV audio, and does not write task titles or reminder text to logs or files.
- If the user selects the browser/system fallback, that same text is supplied to the operating system's speech engine.
- The plugin has no analytics, accounts, cloud API, telemetry, or credentials.
- Piper voice files and their licenses are obtained and managed by the user; this project does not bundle them.

Do not configure the bridge URL to a remote host. The included bridge is deliberately bound to `127.0.0.1`.
