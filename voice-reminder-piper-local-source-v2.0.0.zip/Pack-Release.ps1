$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSCommandPath
$pluginDir = Join-Path $root 'voice-reminder-piper-local'
$dist = Join-Path $root 'dist'
$zip = Join-Path $dist 'voice-reminder-piper-local.zip'
$hash = Join-Path $dist 'voice-reminder-piper-local.zip.sha256'

if (-not (Test-Path -LiteralPath $pluginDir)) { throw "Plugin folder not found: $pluginDir" }
New-Item -ItemType Directory -Force -Path $dist | Out-Null
Compress-Archive -LiteralPath (Join-Path $pluginDir 'manifest.json'), (Join-Path $pluginDir 'plugin.js') -DestinationPath $zip -Force
(Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLowerInvariant() | Set-Content -LiteralPath $hash -NoNewline
Write-Host "Created $zip"
Write-Host "SHA-256: $(Get-Content -LiteralPath $hash -Raw)"
