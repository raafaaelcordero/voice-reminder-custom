// Local Piper voice reminder for Super Productivity.
// No credentials, file paths, or task titles are persisted by this plugin.
(function () {
  var intervalHandle = null;
  var currentTask = null;
  var currentAudio = null;
  var currentAbort = null;
  var unloaded = false;
  var startGeneration = 0;
  var reminderPhraseIndex = 0;
  var defaultIntroductions = [
    '',
    'Animo. ',
    'Buen ritmo. ',
    'Sigue asi. ',
    'Vamos. ',
    'Muy bien. ',
    'Con calma y foco. ',
    'Un paso cada vez. ',
    'Mantente presente. ',
    'Tu avance cuenta. ',
  ];
  var defaultClosings = [
    '',
    ' Continua cuando estes listo.',
    ' Sigue sumando pasos.',
    ' Cada avance importa.',
    ' Hazlo a tu ritmo.',
    ' Vas por buen camino.',
    ' Un poco mas y lo tendras.',
    ' Manten el foco.',
    ' Sigue con confianza.',
    ' Tu esfuerzo se nota.',
    ' Paso a paso se consigue.',
    ' Ahora es un buen momento para avanzar.',
  ];
  var defaults = {
    isEnabled: false,
    text: 'Tu tarea actual es: ${currentTaskTitle}',
    interval: 300000,
    volume: 75,
    provider: 'piper',
    piperUrl: 'http://127.0.0.1:8712',
    piperVoice: 'es_ES-davefx-medium',
    browserVoice: '',
    useVariedPhrases: false,
    customPhrases: '',
  };

  function escapeHtml(value) {
    var node = document.createElement('div');
    node.textContent = String(value);
    return node.innerHTML.replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  function config() {
    return PluginAPI.loadSyncedData().then(function (raw) {
      try {
        return Object.assign({}, defaults, raw ? JSON.parse(raw) : {});
      } catch (_error) {
        return Object.assign({}, defaults);
      }
    });
  }

  function stopAudio() {
    if (currentAbort) currentAbort.abort();
    currentAbort = null;
    if (currentAudio) {
      currentAudio.source.onended = null;
      try {
        currentAudio.source.stop();
      } catch (_error) {
        // The source may already have ended.
      }
      currentAudio.source.disconnect();
      currentAudio.gain.disconnect();
      if (currentAudio.context.close) currentAudio.context.close();
    }
    currentAudio = null;
  }

  function speakBrowser(text, volume, voiceId) {
    if (!window.speechSynthesis) return;
    window.speechSynthesis.cancel();
    var utterance = new SpeechSynthesisUtterance(text);
    var voices = window.speechSynthesis.getVoices();
    utterance.voice =
      voices.find(function (voice) {
        return voice.voiceURI === voiceId || voice.name === voiceId;
      }) || null;
    utterance.volume = Math.max(0, Math.min(1, volume / 100));
    utterance.rate = 0.7;
    window.speechSynthesis.speak(utterance);
  }

  // Davefx handles plain ASCII Spanish more reliably than accented text.
  // This deliberately runs only on the transient copy sent to Piper: the
  // saved reminder and task title remain unchanged.
  function normalizePiperText(text) {
    return String(text)
      .replace(/©/g, ' derechos de autor ')
      .replace(/%/g, ' por ciento ')
      .replace(/€/g, ' euros ')
      .replace(/[¿?¡!]/g, ' ')
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/\s{2,}/g, ' ')
      .replace(/\s+([,.;:!?])/g, '$1')
      .trim();
  }

  function piperRequest(cfg, text) {
    stopAudio();
    var requestAbort = new AbortController();
    currentAbort = requestAbort;
    return fetch(cfg.piperUrl.replace(/\/$/, '') + '/v1/synthesize', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: normalizePiperText(text), voice: cfg.piperVoice }),
      signal: requestAbort.signal,
    })
      .then(function (response) {
        if (!response.ok) throw new Error('Piper bridge returned ' + response.status);
        return response.arrayBuffer();
      })
      .then(function (wavBytes) {
        if (unloaded || currentAbort !== requestAbort) return;
        var AudioContext = window.AudioContext || window.webkitAudioContext;
        if (!AudioContext) throw new Error('Web Audio API unavailable');
        var context = new AudioContext();
        return context.decodeAudioData(wavBytes).then(function (buffer) {
          if (unloaded || currentAbort !== requestAbort) {
            if (context.close) context.close();
            return;
          }
          var source = context.createBufferSource();
          var gain = context.createGain();
          var playback = { context: context, source: source, gain: gain };
          gain.gain.value = Math.max(0, Math.min(1, cfg.volume / 100));
          source.buffer = buffer;
          source.connect(gain);
          gain.connect(context.destination);
          source.onended = function () {
            source.disconnect();
            gain.disconnect();
            if (context.close) context.close();
            if (currentAudio === playback) currentAudio = null;
          };
          currentAudio = playback;
          currentAbort = null;
          return context.resume().then(function () {
            if (unloaded || currentAudio !== playback) return;
            source.start();
          });
        });
      });
  }

  function speak(cfg, text, showFallbackNotice) {
    if (unloaded || !text) return;
    if (cfg.provider !== 'piper') {
      speakBrowser(text, cfg.volume, cfg.browserVoice);
      return;
    }
    piperRequest(cfg, text).catch(function (error) {
      // A local service can be stopped while a timer is running. Keep the
      // established browser voices usable instead of losing a reminder.
      if (error.name !== 'AbortError') {
        speakBrowser(text, cfg.volume, cfg.browserVoice);
        if (showFallbackNotice) {
          PluginAPI.showSnack({
            msg: 'Piper no responde; se ha usado la voz del sistema.',
            type: 'ERROR',
          });
        }
      }
    });
  }

  function reminderText(cfg, taskTitle) {
    var result = String(cfg.text || '').replace('${currentTaskTitle}', taskTitle || '');
    result = result.trim() || taskTitle || '';
    if (!cfg.useVariedPhrases) return result;

    // Parse custom phrases only after the user edits them, not at every reminder.
    if (cfg._customPhraseSource !== cfg.customPhrases) {
      cfg._customPhraseSource = cfg.customPhrases;
      cfg._customPhraseList = String(cfg.customPhrases || '')
        .split(/\r?\n/)
        .map(function (phrase) {
          return phrase.trim();
        })
        .filter(function (phrase) {
          return phrase.length > 0;
        });
    }
    var customPhrases = cfg._customPhraseList;
    if (customPhrases.length) {
      var customPhrase = customPhrases[reminderPhraseIndex % customPhrases.length];
      reminderPhraseIndex += 1;
      return customPhrase.replace('${currentTaskTitle}', taskTitle || '');
    }

    // These module-level arrays yield 120 prompts without allocations per reminder.
    var introduction = defaultIntroductions[reminderPhraseIndex % defaultIntroductions.length];
    var closing =
      defaultClosings[
        Math.floor(reminderPhraseIndex / defaultIntroductions.length) % defaultClosings.length
      ];
    reminderPhraseIndex += 1;
    return introduction + result + closing;
  }

  function stopTimer() {
    if (intervalHandle) clearTimeout(intervalHandle);
    intervalHandle = null;
  }

  function scheduleReminder(cfg, myGeneration) {
    // Do not keep an idle timer alive while no task is being tracked.
    if (unloaded || myGeneration !== startGeneration || !cfg.isEnabled || !currentTask) {
      intervalHandle = null;
      return;
    }
    intervalHandle = setTimeout(function () {
      intervalHandle = null;
      if (unloaded || myGeneration !== startGeneration || !currentTask) return;
      speak(cfg, reminderText(cfg, currentTask.title), false);
      scheduleReminder(cfg, myGeneration);
    }, Math.max(5000, Number(cfg.interval) || defaults.interval));
  }

  function startTimer() {
    var myGeneration = ++startGeneration;
    stopTimer();
    return config().then(function (cfg) {
      if (unloaded || myGeneration !== startGeneration || !cfg.isEnabled) return;
      scheduleReminder(cfg, myGeneration);
    });
  }

  function browserOptions(selected) {
    var voices = window.speechSynthesis ? window.speechSynthesis.getVoices() : [];
    var options = '<option value="">Predeterminada del sistema</option>';
    voices.forEach(function (voice) {
      var selectedAttr = voice.voiceURI === selected ? ' selected' : '';
      options +=
        '<option value="' +
        escapeHtml(voice.voiceURI) +
        '"' +
        selectedAttr +
        '>' +
        escapeHtml(voice.name) +
        '</option>';
    });
    return options;
  }

  function loadPiperVoices(url, selected) {
    return fetch(url.replace(/\/$/, '') + '/v1/voices')
      .then(function (response) {
        if (!response.ok) throw new Error('bridge unavailable');
        return response.json();
      })
      .then(function (payload) {
        return (payload.voices || []).map(function (voice) {
          return (
            '<option value="' +
            escapeHtml(voice.id) +
            '"' +
            (voice.id === selected ? ' selected' : '') +
            '>' +
            escapeHtml(voice.name || voice.id) +
            '</option>'
          );
        });
      });
  }

  function openSettings() {
    config().then(function (cfg) {
      var html =
        '<div style="padding:4px 0">' +
        '<p style="margin:0 0 16px;opacity:.7">Repite el recordatorio mientras registras tiempo en una tarea. Piper funciona únicamente en este PC.</p>' +
        '<label><input id="vr-enabled" type="checkbox"' +
        (cfg.isEnabled ? ' checked' : '') +
        '> Activar recordatorio de voz</label>' +
        '<p><label>Texto (usa ${currentTaskTitle}):<br><input id="vr-text" style="width:100%" value="' +
        escapeHtml(cfg.text) +
        '"></label></p>' +
        '<p><label><input id="vr-varied-phrases" type="checkbox"' +
        (cfg.useVariedPhrases ? ' checked' : '') +
        '> Alternar frases motivadoras (tono más animado)</label></p>' +
        '<p><label>Frases personalizadas (una por línea; puedes usar ${currentTaskTitle}):<br><textarea id="vr-custom-phrases" style="width:100%;min-height:100px" placeholder="Vamos con ${currentTaskTitle}.&#10;Animo, sigue con ${currentTaskTitle}.">' +
        escapeHtml(cfg.customPhrases) +
        '</textarea></label><br><small>Si hay frases aquí y activas la alternancia, se usarán en orden.</small></p>' +
        '<p><label>Intervalo (segundos):<br><input id="vr-interval" type="number" min="5" value="' +
        Math.round(cfg.interval / 1000) +
        '"></label></p>' +
        '<p><label>Volumen: <span id="vr-volume-value">' +
        cfg.volume +
        '</span><br><input id="vr-volume" type="range" min="0" max="100" value="' +
        cfg.volume +
        '"></label></p>' +
        '<p><label><input id="vr-provider-piper" name="vr-provider" type="radio" value="piper"' +
        (cfg.provider === 'piper' ? ' checked' : '') +
        '> Piper local</label><br><label><input id="vr-provider-browser" name="vr-provider" type="radio" value="browser"' +
        (cfg.provider !== 'piper' ? ' checked' : '') +
        '> Voz de Windows/navegador</label></p>' +
        '<p><label>Voz Piper:<br><select id="vr-piper-voice" style="width:100%"><option value="' +
        escapeHtml(cfg.piperVoice) +
        '">' +
        escapeHtml(cfg.piperVoice) +
        '</option></select></label></p>' +
        '<p><label>Voz de Windows/navegador (también se usa si Piper falla):<br><select id="vr-browser-voice" style="width:100%">' +
        browserOptions(cfg.browserVoice) +
        '</select></label></p>' +
        '<button id="vr-test" type="button">Probar voz</button>' +
        '</div>';
      PluginAPI.openDialog({
        title: 'Voice Reminder — Piper local',
        htmlContent: html,
        buttons: [
          { label: 'Cancelar', onClick: function () {} },
          { label: 'Guardar', color: 'primary', raised: true, onClick: save },
        ],
      });

      setTimeout(function () {
        var volume = document.getElementById('vr-volume');
        if (volume) {
          volume.addEventListener('input', function () {
            document.getElementById('vr-volume-value').textContent = volume.value;
          });
        }
        loadPiperVoices(cfg.piperUrl, cfg.piperVoice)
          .then(function (options) {
            var select = document.getElementById('vr-piper-voice');
            if (select && options.length) select.innerHTML = options.join('');
          })
          .catch(function () {
            // The configured model remains selectable; the Test button reports fallback.
          });
        var test = document.getElementById('vr-test');
        if (test) {
          test.addEventListener('click', function () {
            var staged = readDialog(cfg);
            speak(staged, reminderText(staged, 'tarea de prueba'), true);
          });
        }
      }, 100);

      function readDialog(previous) {
        function byId(id) {
          return document.getElementById(id);
        }
        var enabled = byId('vr-enabled');
        var text = byId('vr-text');
        var interval = byId('vr-interval');
        var volume = byId('vr-volume');
        var variedPhrases = byId('vr-varied-phrases');
        var customPhrases = byId('vr-custom-phrases');
        var piperVoice = byId('vr-piper-voice');
        var browserVoice = byId('vr-browser-voice');
        var piperProvider = byId('vr-provider-piper');
        return Object.assign({}, previous, {
          isEnabled: enabled ? enabled.checked : false,
          text: text ? text.value : previous.text,
          useVariedPhrases: variedPhrases ? variedPhrases.checked : false,
          customPhrases: customPhrases ? customPhrases.value : previous.customPhrases,
          interval: Math.max(5, Number(interval && interval.value) || 300) * 1000,
          volume: Number(volume && volume.value) || 0,
          provider: piperProvider && piperProvider.checked ? 'piper' : 'browser',
          piperVoice: piperVoice ? piperVoice.value : previous.piperVoice,
          browserVoice: browserVoice ? browserVoice.value : previous.browserVoice,
        });
      }

      function save() {
        var next = readDialog(cfg);
        return PluginAPI.persistDataSynced(JSON.stringify(next)).then(function () {
          return startTimer().then(function () {
            PluginAPI.showSnack({ msg: 'Configuración de voz guardada.', type: 'SUCCESS' });
          });
        });
      }
    });
  }

  PluginAPI.registerHook('currentTaskChange', function (payload) {
    var hadCurrentTask = Boolean(currentTask);
    currentTask = payload && payload.current ? payload.current : null;
    if (!currentTask) {
      stopTimer();
      stopAudio();
    } else if (!hadCurrentTask) {
      startTimer();
    }
  });
  PluginAPI.registerConfigHandler(openSettings);
  PluginAPI.onUnload(function () {
    unloaded = true;
    stopTimer();
    stopAudio();
    if (window.speechSynthesis) window.speechSynthesis.cancel();
  });
  startTimer();
})();
